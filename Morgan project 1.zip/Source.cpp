#include "Clock.h"
#include <conio.h>


// creates the main display for the project 
void menu()
{
    cout << "*************************************" << endl;
    cout << "* 1 - Add One Hour *" << endl;
    cout << "* 2 - Add One Minute *" << endl;
    cout << "* 3 - Add One Second *" << endl;
    cout << "* 4 - Exit *" << endl;
    cout << "*************************************" << endl;
}

// creates the main fuction 
int main()
{
    Clock clock12(false), clock24(true);    // creates the clock variable 
    int choice;  // initaialize the variable called choice
    bool exit = false;  // same as above for exit
    while (!exit)   // creates a while loop for the exit variable 
    {
        cout << "**************** ****************" << endl;
        cout << "* " << setw(12);
        clock12.displayTime(cout);
        cout << " * ";
        cout << "* " << setw(12);
        clock24.displayTime(cout);
        cout << " *" << endl;
        cout << "**************** ****************" << endl;
        cout << endl;
        menu();
        cin >> choice;
        switch (choice)   // creates a switch for the choice variable to add hours, mins, and seconds
        {
        case 1:
            clock12.addHours(1);
            clock24.addHours(1);
            break;
        case 2:
            clock12.addMinutes(1);
            clock24.addMinutes(1);
            break;
        case 3:
            clock12.addSeconds(1);
            clock24.addSeconds(1);
            break;
        case 4:
            exit = true;
        default:
            break;

        }
        system("CLS");
    }

}